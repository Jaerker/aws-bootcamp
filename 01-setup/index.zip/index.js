


exports.handler = async (event) => {
    const response = {
        statusCode:  200,
        body:        JSON.stringify('Well hello there!'),
    };
 
   return response;
}